<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class production_log extends Model
{
    //
}
