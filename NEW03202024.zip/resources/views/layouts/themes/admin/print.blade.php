<!DOCTYPE html>
<html>
<head>
    @include('layouts.partials.admin.head')
</head>
    <body>
        @yield('content')
        @include('layouts.partials.admin.script')
    </body>
</html>
