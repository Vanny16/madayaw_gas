<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="https://fms.umin.edu.ph">
                <img src="{{ asset('images/logo.png') }}" class="logo">
                {{-- <div class="logo-bottom-curve"></div> --}}
            </a>
        </div>
        <ul class="nav navbar-top-links navbar-right"> 
            {{-- <li class="button">
                <a href="{{ action('MainController@landing',[$src_id]) }}"><i class="fa fa-home"></i></a>
            </li> --}}
        </ul>
    </div>
</nav>

