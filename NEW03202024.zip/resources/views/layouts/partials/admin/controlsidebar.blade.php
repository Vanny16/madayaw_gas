  <aside class="control-sidebar control-sidebar-light">
    {{-- Control sidebar content goes here --}}
  </aside>