<script src="{{ asset('bootstrap/public/plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('bootstrap/public/dist/js/adminlte.min.js') }}"></script>

