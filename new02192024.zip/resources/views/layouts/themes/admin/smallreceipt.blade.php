<!DOCTYPE html>
<html>
<head>
    <style>
        html{
            font-size: 10px;
        }
    </style>
</head>
    <body>
        @yield('content')
        @include('layouts.partials.admin.script')
    </body>
</html>
