<title>Infinit | HRIS</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="UM Feedback Management System">
<meta name="author" content="University of Mindanao">
<link rel="shortcut icon" href="{{ asset('favicon.ico') }}">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<link rel="stylesheet" href="{{ asset('bootstrap/public/plugins/fontawesome-free/css/all.min.css')}}">
<link rel="stylesheet" href="{{ asset('bootstrap/public/plugins/icheck-bootstrap/icheck-bootstrap.min.css')}}">
<link rel="stylesheet" href="{{ asset('bootstrap/public/dist/css/adminlte.min.css')}}">
<link rel="stylesheet" href="{{ asset('bootstrap/public/custom/theme.css')}}">
<script src="{{ asset('bootstrap/public/plugins/jquery/jquery.min.js') }}"></script>



