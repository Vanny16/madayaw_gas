<script src="{{ asset('bootstrap/landing/js/jquery.min.js') }}"></script>
<script src="{{ asset('bootstrap/landing/js/popper.js') }}"></script>
<script src="{{ asset('bootstrap/landing/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('bootstrap/landing/js/main.js') }}"></script>
<script src="{{ asset('bootstrap/admin/plugins/sweetalert2/sweetalert2.all.js') }}"></script>